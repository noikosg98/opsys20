var searchData=
[
  ['description_504',['description',['../structTest.html#a294ca3f1114240c908f66216afcad783',1,'Test']]],
  ['dev_5ffops_505',['dev_fops',['../structdevice__control__block.html#a2945d5da96f40ff7fae94e295624a7c7',1,'device_control_block']]],
  ['devnum_506',['devnum',['../structdevice__control__block.html#a25d8f038a1c6d41f445d078276117fba',1,'device_control_block']]]
];

var searchData=
[
  ['main_5ftask_521',['main_task',['../structprocess__control__block.html#a7d4ddbf8f67ac2bfe9774796b818354e',1,'process_control_block::main_task()'],['../structprocinfo.html#a4da339065f8780b37ab788f18ef9ed20',1,'procinfo::main_task()']]],
  ['main_5fthread_522',['main_thread',['../structprocess__control__block.html#a3b7a2a952ec5c19d7331307639c78482',1,'process_control_block']]],
  ['minimum_5fcores_523',['minimum_cores',['../structTest.html#ac203918837b4c6718a020246e189a95a',1,'Test']]],
  ['minimum_5fterminals_524',['minimum_terminals',['../structTest.html#a2741188633c51b8e3cb545fa3971bf60',1,'Test']]],
  ['mx_525',['mx',['../structSymposiumTable.html#a8c36f26f523e6b2f99f6e70fff098de8',1,'SymposiumTable']]]
];

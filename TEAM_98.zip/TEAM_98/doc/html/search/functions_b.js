var searchData=
[
  ['openinfo_439',['OpenInfo',['../group__syscalls.html#gaf326b11574cdc84a9e21b9d860076821',1,'tinyos.h']]],
  ['opennull_440',['OpenNull',['../group__syscalls.html#ga39805b4ae668b715fb43f0f1e6ce8c45',1,'tinyos.h']]],
  ['openterminal_441',['OpenTerminal',['../group__syscalls.html#ga6ea2b586a8dfcfc1e7065e1664a0fb35',1,'tinyos.h']]]
];

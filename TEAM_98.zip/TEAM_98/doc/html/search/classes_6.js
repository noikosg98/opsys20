var searchData=
[
  ['logrec_345',['logrec',['../structlogrec.html',1,'']]]
];

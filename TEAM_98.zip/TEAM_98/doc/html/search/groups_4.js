var searchData=
[
  ['macros_20for_20checking_20system_20calls_2e_640',['Macros for checking system calls.',['../group__check__macros.html',1,'']]]
];

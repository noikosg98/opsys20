var searchData=
[
  ['pipe_5fs_346',['pipe_s',['../structpipe__s.html',1,'']]],
  ['process_5fcontrol_5fblock_347',['process_control_block',['../structprocess__control__block.html',1,'']]],
  ['procinfo_348',['procinfo',['../structprocinfo.html',1,'']]],
  ['program_5farguments_349',['program_arguments',['../structprogram__arguments.html',1,'']]]
];

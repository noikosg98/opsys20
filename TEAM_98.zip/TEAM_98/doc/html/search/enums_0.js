var searchData=
[
  ['device_5ftype_592',['Device_type',['../group__dev.html#ga879ceac20e83b2375e5b49f4379b0c90',1,'kernel_dev.h']]]
];
